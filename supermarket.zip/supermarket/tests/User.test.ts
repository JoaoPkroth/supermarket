import { Admin } from "../src/models/Admin"

describe("Classe User (via Admin)", function () {
  let admin: Admin

  beforeEach(function () {
    admin = new Admin(1, "Maria Silva", "maria@mercado.com")
  })

  // CT02
  test("CT02 - deve rejeitar ID igual a zero", function () {
    let mensagem = ""

    try {
      new Admin(0, "Maria Silva", "maria@mercado.com")
    } catch (erro) {
      if (erro instanceof Error) {
        mensagem = erro.message
      }
    }

    expect(mensagem).toContain("User ID must be a positive integer.")
  })

  // CT07
  const emailsInvalidos = ["email-invalido", "sem@dominio", "@mercado.com", "com espaco@x.com", ""]

  for (let i = 0; i < emailsInvalidos.length; i++) {
    const emailInvalido = emailsInvalidos[i]

    test("CT07 - deve rejeitar e-mail inválido: '" + emailInvalido + "'", function () {
      let mensagem = ""

      try {
        new Admin(2, "João Souza", emailInvalido)
      } catch (erro) {
        if (erro instanceof Error) {
          mensagem = erro.message
        }
      }

      expect(mensagem).toContain("A valid email address is required.")
    })
  }

  // CT12
  test("CT12 - deve atualizar o e-mail com dado válido e normalizá-lo", function () {
    admin.updateEmail("  NOVO.Email@Mercado.COM  ")

    expect(admin.getEmail()).toBe("novo.email@mercado.com")
  })
})
