jest.mock("readline-sync", function () {
  return {
    __esModule: true,
    default: {
      question: jest.fn(),
      questionInt: jest.fn(),
      questionFloat: jest.fn(),
    },
  }
})

type ReadlineMock = {
  question: jest.Mock
  questionInt: jest.Mock
  questionFloat: jest.Mock
}

function silenciar(): void {}

describe("Interface de terminal (main.ts)", function () {
  let rl: ReadlineMock
  let logSpy: jest.SpyInstance

  function runMain(questions: string[], ints: number[] = []): void {
    for (let i = 0; i < questions.length; i++) {
      rl.question.mockReturnValueOnce(questions[i])
    }

    for (let i = 0; i < ints.length; i++) {
      rl.questionInt.mockReturnValueOnce(ints[i])
    }

    require("../src/main")
  }

  function printedLines(): string[] {
    const linhas: string[] = []

    for (let i = 0; i < logSpy.mock.calls.length; i++) {
      linhas.push(logSpy.mock.calls[i].join(" "))
    }

    return linhas
  }

  beforeEach(function () {
    jest.resetModules()
    rl = require("readline-sync").default as ReadlineMock
    rl.question.mockReset()
    rl.questionInt.mockReset()
    rl.questionFloat.mockReset()

    jest.spyOn(console, "clear").mockImplementation(silenciar)
    logSpy = jest.spyOn(console, "log").mockImplementation(silenciar)
  })

  afterEach(function () {
    jest.restoreAllMocks()
  })

  // CT72
  test("CT72 - deve exibir o menu principal com todas as opções", function () {
    runMain(["0"])

    const lines = printedLines()
    const esperadas = [
      "   SUPERMARKET EMPLOYEE SYSTEM",
      "1. List users",
      "2. Find user by ID",
      "3. Register employee",
      "4. Register supervisor",
      "5. Register admin",
      "6. Remove user",
      "0. Exit",
    ]

    for (let i = 0; i < esperadas.length; i++) {
      expect(lines).toContain(esperadas[i])
    }
  })

  // CT78
  describe("CT78 - remoção de usuário", function () {
    test("deve exibir mensagem de sucesso ao remover um usuário existente", function () {
      runMain(
        ["4", "Carlos Souza", "carlos@mercado.com", "", "6", "", "0"],
        [2, 2]
      )

      const lines = printedLines()
      expect(lines).toContain("\nRegistered successfully:")
      expect(lines).toContain("User removed successfully.")
      expect(lines).not.toContain("User not found.")
    })

    test("deve exibir erro ao tentar remover um usuário inexistente", function () {
      runMain(["6", "", "0"], [99])

      const lines = printedLines()
      expect(lines).toContain("User not found.")
      expect(lines).not.toContain("User removed successfully.")
    })
  })
})
