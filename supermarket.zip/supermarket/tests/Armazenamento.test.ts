import { Admin } from "../src/models/Admin"
import { Employee } from "../src/models/Employee"
import { Armazenamento } from "../src/services/Armazenamento"

describe("Classe Armazenamento", function () {
  let storage: Armazenamento
  let admin: Admin
  let employee: Employee

  beforeEach(function () {
    storage = new Armazenamento()
    admin = new Admin(1, "Admin Geral", "Admin@Mercado.com")
    employee = new Employee(2, "Ana Lima", "ana@mercado.com", 2500, "Padaria")
    storage.addUser(admin)
    storage.addUser(employee)
  })

  // CT39
  test("CT39 - deve buscar usuário por e-mail sem diferenciar maiúsculas e minúsculas", function () {
    const encontrado = storage.findUserByEmail("ADMIN@MERCADO.COM")

    expect(encontrado).toBe(admin)
    expect(encontrado.getId()).toBe(1)
  })

  test("CT39 - deve ignorar espaços externos na busca por e-mail", function () {
    const encontrado = storage.findUserByEmail("  Ana@Mercado.com  ")

    expect(encontrado).toBe(employee)
    expect(encontrado.getId()).toBe(2)
  })
})
