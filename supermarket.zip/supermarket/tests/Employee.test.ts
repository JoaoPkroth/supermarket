import { Employee } from "../src/models/Employee"

describe("Classe Employee", function () {
  let employee: Employee

  beforeEach(function () {
    employee = new Employee(10, "Ana Lima", "ana@mercado.com", 2500, "Padaria")
  })

  // CT23
  describe("CT23 - salário não finito", function () {
    const salariosInvalidos = [NaN, Infinity, -Infinity]

    for (let i = 0; i < salariosInvalidos.length; i++) {
      const salarioInvalido = salariosInvalidos[i]

      test("deve rejeitar salário " + salarioInvalido + " na criação", function () {
        let mensagem = ""

        try {
          new Employee(11, "Bruno Reis", "bruno@mercado.com", salarioInvalido, "Açougue")
        } catch (erro) {
          if (erro instanceof Error) {
            mensagem = erro.message
          }
        }

        expect(mensagem).toContain("Salary must be a finite number greater than zero.")
      })
    }
  })

  // CT24
  test("CT24 - deve rejeitar departamento vazio", function () {
    let mensagem = ""

    try {
      new Employee(12, "Carla Dias", "carla@mercado.com", 3000, "")
    } catch (erro) {
      if (erro instanceof Error) {
        mensagem = erro.message
      }
    }

    expect(mensagem).toContain("Department cannot be empty.")
  })

  // CT27
  test("CT27 - deve atualizar o salário com valor válido", function () {
    employee.updateSalary(4200.5)

    expect(employee.getSalary()).toBe(4200.5)
  })

  // CT30
  describe("CT30 - atualização com departamento inválido", function () {
    const departamentosInvalidos = ["", "   "]

    for (let i = 0; i < departamentosInvalidos.length; i++) {
      const departamentoInvalido = departamentosInvalidos[i]

      test("deve rejeitar o departamento '" + departamentoInvalido + "' e preservar o anterior", function () {
        let mensagem = ""

        try {
          employee.updateDepartment(departamentoInvalido)
        } catch (erro) {
          if (erro instanceof Error) {
            mensagem = erro.message
          }
        }

        expect(mensagem).toContain("Department cannot be empty.")
        expect(employee.getDepartment()).toBe("Padaria")
      })
    }
  })
})
