import { Admin } from "../src/models/Admin"
import { Employee } from "../src/models/Employee"
import { Supervisor } from "../src/models/Supervisor"
import { Armazenamento } from "../src/services/Armazenamento"
import { EmployeeService } from "../src/services/EmployeeService"

describe("Classe EmployeeService", function () {
  let storage: Armazenamento
  let service: EmployeeService
  let admin: Admin
  let supervisor: Supervisor
  let employee: Employee

  beforeEach(function () {
    storage = new Armazenamento()
    service = new EmployeeService(storage)

    admin = new Admin(1, "Admin Geral", "admin@mercado.com")
    supervisor = new Supervisor(2, "Sara Costa", "sara@mercado.com")
    employee = new Employee(3, "Ana Lima", "ana@mercado.com", 2500, "Padaria")

    storage.addUser(admin)
    storage.addUser(supervisor)
    storage.addUser(employee)
  })

  // CT69
  test("CT69 - deve rejeitar remoção realizada por funcionário", function () {
    let mensagem = ""

    try {
      service.removeUser(employee, 2)
    } catch (erro) {
      if (erro instanceof Error) {
        mensagem = erro.message
      }
    }

    expect(mensagem).toContain("Permission denied. Admin access is required.")

    expect(storage.getUserCount()).toBe(3)
    expect(storage.findUserById(2)).toBe(supervisor)
  })

  // CT71
  test("CT71 - deve propagar o erro ao remover usuário inexistente pelo serviço", function () {
    let mensagem = ""

    try {
      service.removeUser(admin, 999)
    } catch (erro) {
      if (erro instanceof Error) {
        mensagem = erro.message
      }
    }

    expect(mensagem).toContain("User not found.")

    expect(storage.getUserCount()).toBe(3)
  })
})
